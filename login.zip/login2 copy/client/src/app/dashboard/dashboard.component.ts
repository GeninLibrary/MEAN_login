import { Component, OnInit } from '@angular/core';
import { PetService } from './../pet.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
pet;
pets = [];
  constructor(private _petService: PetService, private _route: ActivatedRoute) {
    this._route.paramMap.subscribe( data => {
     
      
      console.log("Is the dashboard constructor working?", data.get('id'));
 });

}
destroyPet(id){
  console.log("Dashboard component", id)
  this._petService.destroyPet(id)
}

  ngOnInit() {
    this._petService.pets.subscribe(data=>{
      this.pets = data;
    })
  }

}


