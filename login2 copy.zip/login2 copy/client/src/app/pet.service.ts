import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CreateComponent } from './create/create.component';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

@Injectable()
export class PetService {
  pets = new BehaviorSubject([])

  constructor(private _http: HttpClient) {
    this.getPets(data=>{
      this.pets.next(data);
    })

   
   }
   createPet(pet, cb){
    // console.log(pet);
    this._http.post('/createPet', pet).subscribe((data)=> {
      console.log(data);
      this.getPets((data)=>{
        this.pets.next(data);
        cb(data);
      })
    })
  }
  
  getPets(cb){
    this._http.get('/getPets').subscribe((data)=> {
      console.log(data);
      cb(data);
    })
  }

  destroyPet(id){
    console.log("destroy PetService")
    this._http.post('/destroyPet/:id', {id:id}).subscribe((data)=>{
      console.log("Here's Pet Service", data);
    })
  }

}