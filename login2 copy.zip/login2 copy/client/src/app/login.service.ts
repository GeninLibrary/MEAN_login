import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { LoginComponent } from './login/login.component';


@Injectable()
export class LoginService {
user;
  constructor(private _http: HttpClient) { }

  getSession(user, cb){
    this._http.post('/login', user).subscribe((data)=>{ //subscribe is needed to connect to routes.js
      // console.log(data);
      cb(data);
    })
  }
}
