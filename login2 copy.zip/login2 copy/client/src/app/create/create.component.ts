import { Component, OnInit } from '@angular/core';
import { PetService } from './../pet.service';
import { LoginService } from './../login.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.css']
})
export class CreateComponent implements OnInit {
pet;
  constructor(private _petService:PetService,private _loginService: LoginService, private _router: Router) { 
    this.pet={name: "", species: ""}
  }

  createPet(){
    // console.log(this.pet)
    this._petService.createPet(this.pet, data=> {  
      if(!data.user){
        this._router.navigate(['/dashboard']);
      }
    });
  }

  ngOnInit() {
  }

}
