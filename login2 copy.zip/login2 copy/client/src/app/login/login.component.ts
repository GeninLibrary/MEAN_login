import { Component, OnInit } from '@angular/core';
import { LoginService } from '../login.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
user;
  constructor(private _loginService: LoginService, private _router: Router) {
    this.user = {name: ""}
   }

getSession(){
  this._loginService.getSession(this.user, data=> {  
    if(!data.user){
      this._router.navigate(['/dashboard']);
    }
  });
}

  ngOnInit() {
  }

}
